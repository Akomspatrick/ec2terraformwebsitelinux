﻿namespace WebHookPoc.WebHook
{
    public class DPData
    {
        public string Data { get; init; }
        public string key { get; init; }
    }
}
