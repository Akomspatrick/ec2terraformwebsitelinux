#!/bin/bash
rm -rf BigG/
mkdir BigG
cp -r * ./BigG
tar -czvf  archive.tar.gz BigG/
